# BBS website

### Schedule
[![Schedule](http://www.worldpara.com/ITWS%20Term%20Project.png "Schedule")](http://www.worldpara.com/ITWS%20Term%20Project.png "Schedule")

### Notes from Group Meeting
#### 10/24
- Everyone now has access to the server

#### 10/31
- Everyone now which part of the project to do


